package com.example.thymeleaf.service;

import java.util.List;

import com.example.thymeleaf.entity.Products;

public interface ProductService {
	public List<Products> findAll();
	public void save(Products p);
	public Products findById(Integer id);
	public void deleteById(Integer id);
}

