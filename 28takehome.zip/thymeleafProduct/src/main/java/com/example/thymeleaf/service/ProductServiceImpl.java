package com.example.thymeleaf.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.thymeleaf.Repository.ProductRepository;
import com.example.thymeleaf.entity.Products;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository ProductRepo;

	public List<Products> findAll() {

		return ProductRepo.findAll();
	}

	@Transactional
	public void save(Products p) {

		ProductRepo.save(p);
	}

	public Products findById(Integer id) {

		Optional<Products> p = ProductRepo.findById(id);
		Products emp = null;

		if (p.isPresent())
			emp = p.get();

		return emp;
	}

	public void deleteById(Integer id) {
		ProductRepo.deleteById(id);

	}

}
